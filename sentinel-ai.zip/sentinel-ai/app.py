"""
app.py
Sentinel-AI - single dashboard tying together every security module
and the AI triage agent. This is the "one tool" entry point.

Run:
    python3 app.py
Then open http://127.0.0.1:5000
"""

import threading
import json
from flask import Flask, render_template, request, jsonify

from database import init_db, get_recent_events, get_conn
from modules import port_scanner, file_integrity
from modules import ids_monitor
from modules import web_vuln_scanner, password_cracker, keylogger_detector, phishing_detector, firewall_sim
import ai_agent

app = Flask(__name__)
init_db()

# ---- background threads (started lazily, once) -----------------------
_threads_started = {"ids": False, "ai": False, "fim": False}


def _start_background_ids(interface=None):
    if not _threads_started["ids"]:
        t = threading.Thread(target=ids_monitor.start_monitoring, args=(interface,), daemon=True)
        t.start()
        _threads_started["ids"] = True


def _start_background_ai():
    if not _threads_started["ai"]:
        t = threading.Thread(target=ai_agent.run_forever, args=(10,), daemon=True)
        t.start()
        _threads_started["ai"] = True


def _start_background_fim(watch_dir="."):
    if not _threads_started["fim"]:
        t = threading.Thread(target=file_integrity.watch_loop, args=(watch_dir, 15), daemon=True)
        t.start()
        _threads_started["fim"] = True


# ---- routes -------------------------------------------------------------

@app.route("/")
def dashboard():
    events = get_recent_events(limit=100)
    return render_template("dashboard.html", events=events)


@app.route("/api/events")
def api_events():
    return jsonify(get_recent_events(limit=100))


@app.route("/api/scan", methods=["POST"])
def api_scan():
    target = request.json.get("target", "127.0.0.1")
    open_ports = port_scanner.scan_target(target)
    return jsonify({"target": target, "open_ports": open_ports})


@app.route("/api/start-ids", methods=["POST"])
def api_start_ids():
    interface = request.json.get("interface")
    _start_background_ids(interface)
    return jsonify({"status": "IDS monitor starting (needs sudo/root to capture packets)"})


@app.route("/api/start-fim", methods=["POST"])
def api_start_fim():
    watch_dir = request.json.get("watch_dir", ".")
    _start_background_fim(watch_dir)
    return jsonify({"status": f"File integrity monitor watching {watch_dir}"})


@app.route("/api/start-ai", methods=["POST"])
def api_start_ai():
    _start_background_ai()
    return jsonify({"status": "AI triage agent started (requires ANTHROPIC_API_KEY)"})


@app.route("/api/web-scan", methods=["POST"])
def api_web_scan():
    target = request.json.get("target", "http://127.0.0.1")
    findings = web_vuln_scanner.scan_site(target)
    return jsonify({"target": target, "findings": findings})


@app.route("/api/crack-password", methods=["POST"])
def api_crack_password():
    target_hash = request.json.get("hash")
    algo = request.json.get("algo", "sha256")
    max_len = int(request.json.get("max_length", 4))
    if not target_hash:
        # convenience: allow passing a plaintext to hash-then-crack, for demos
        plaintext = request.json.get("password", "password1")
        target_hash = password_cracker.hash_password(plaintext, algo)
    result = password_cracker.crack(target_hash, algo=algo, max_brute_length=max_len)
    return jsonify(result)


@app.route("/api/scan-processes", methods=["POST"])
def api_scan_processes():
    findings = keylogger_detector.scan_processes()
    return jsonify({"findings": findings})


@app.route("/api/check-phishing", methods=["POST"])
def api_check_phishing():
    url = request.json.get("url", "http://example.com")
    result = phishing_detector.analyze_url(url)
    return jsonify(result)


@app.route("/api/firewall-test", methods=["POST"])
def api_firewall_test():
    packets = request.json.get("packets") or firewall_sim.sample_traffic()
    results = firewall_sim.evaluate_batch(packets)
    return jsonify({"results": results})


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=5050, debug=True, use_reloader=False)
