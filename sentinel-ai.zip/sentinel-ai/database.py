"""
database.py
Central SQLite database used by ALL modules and the AI agent.
Every module writes its findings here so the dashboard + AI agent
can read from a single source of truth.
"""

import sqlite3
import os
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "sentinel.db")


def get_conn():
    conn = sqlite3.connect(DB_PATH, check_same_thread=False)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_conn()
    cur = conn.cursor()

    # Generic events table - every module logs here
    cur.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            module TEXT NOT NULL,       -- e.g. 'port_scanner', 'ids_monitor'
            severity TEXT NOT NULL,      -- info | warning | critical
            title TEXT NOT NULL,
            details TEXT,                -- JSON string with extra data
            ai_verdict TEXT,              -- filled in later by the AI agent
            ai_reasoning TEXT
        )
    """)

    # Port scan results
    cur.execute("""
        CREATE TABLE IF NOT EXISTS port_scans (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            timestamp TEXT NOT NULL,
            target TEXT NOT NULL,
            port INTEGER NOT NULL,
            state TEXT NOT NULL,
            service TEXT
        )
    """)

    # File integrity baseline + changes
    cur.execute("""
        CREATE TABLE IF NOT EXISTS file_hashes (
            path TEXT PRIMARY KEY,
            hash TEXT NOT NULL,
            last_checked TEXT NOT NULL
        )
    """)

    conn.commit()
    conn.close()


def log_event(module, severity, title, details="", ai_verdict=None, ai_reasoning=None):
    conn = get_conn()
    conn.execute(
        """INSERT INTO events (timestamp, module, severity, title, details, ai_verdict, ai_reasoning)
           VALUES (?, ?, ?, ?, ?, ?, ?)""",
        (datetime.utcnow().isoformat(), module, severity, title, details, ai_verdict, ai_reasoning),
    )
    conn.commit()
    conn.close()


def get_recent_events(limit=50):
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM events ORDER BY id DESC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def get_unanalyzed_events(limit=20):
    """Events the AI agent hasn't looked at yet."""
    conn = get_conn()
    rows = conn.execute(
        "SELECT * FROM events WHERE ai_verdict IS NULL ORDER BY id ASC LIMIT ?", (limit,)
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def set_ai_verdict(event_id, verdict, reasoning):
    conn = get_conn()
    conn.execute(
        "UPDATE events SET ai_verdict = ?, ai_reasoning = ? WHERE id = ?",
        (verdict, reasoning, event_id),
    )
    conn.commit()
    conn.close()


# Auto-initialize schema on import so any module/script that imports
# database.py can be run standalone (e.g. `python3 modules/port_scanner.py`)
# without needing to remember to call init_db() first.
init_db()
