"""
ai_agent.py
The "brain" of Sentinel-AI. Periodically pulls unanalyzed events from the
database, sends them to Claude for triage, and writes back a verdict +
reasoning. This is what turns a pile of separate scripts into one
AI-driven security agent.

Requires: pip install anthropic
Set your key:  export ANTHROPIC_API_KEY="sk-ant-..."
"""

import os
import time
import json

from database import get_unanalyzed_events, set_ai_verdict, get_recent_events

try:
    import anthropic
    CLIENT_AVAILABLE = True
except ImportError:
    CLIENT_AVAILABLE = False

MODEL = "claude-sonnet-4-6"

SYSTEM_PROMPT = """You are a security analyst AI embedded in a home-lab
monitoring tool called Sentinel-AI. You receive raw events from tools like
a port scanner, packet-based IDS, and a file integrity monitor.

For each event, respond with ONLY a JSON object (no markdown, no preamble):
{
  "verdict": "benign" | "suspicious" | "malicious",
  "reasoning": "one or two sentence explanation in plain English",
  "recommended_action": "short actionable next step"
}

Be concise and practical. This is a lab/home-network context, so weigh
likelihood accordingly (e.g. a single open SSH port on a home server is
usually 'benign' unless paired with other signals).
"""


def analyze_event(event):
    if not CLIENT_AVAILABLE:
        return {"verdict": "unknown", "reasoning": "anthropic package not installed", "recommended_action": "pip install anthropic"}

    client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from env

    user_content = json.dumps({
        "module": event["module"],
        "severity": event["severity"],
        "title": event["title"],
        "details": event["details"],
    })

    response = client.messages.create(
        model=MODEL,
        max_tokens=300,
        system=SYSTEM_PROMPT,
        messages=[{"role": "user", "content": user_content}],
    )

    text = "".join(block.text for block in response.content if block.type == "text")
    text = text.strip().strip("`").replace("json\n", "", 1)

    try:
        parsed = json.loads(text)
    except json.JSONDecodeError:
        parsed = {"verdict": "unknown", "reasoning": text, "recommended_action": "manual review needed"}

    return parsed


def run_triage_cycle(limit=20):
    """Pull unanalyzed events, get an AI verdict for each, save it back."""
    events = get_unanalyzed_events(limit=limit)
    results = []
    for event in events:
        verdict = analyze_event(event)
        set_ai_verdict(
            event["id"],
            verdict.get("verdict", "unknown"),
            f"{verdict.get('reasoning', '')} | Action: {verdict.get('recommended_action', '')}",
        )
        results.append({"event_id": event["id"], "title": event["title"], **verdict})
    return results


def run_forever(poll_seconds=10):
    print(f"AI agent running - polling every {poll_seconds}s for new events...")
    while True:
        results = run_triage_cycle()
        for r in results:
            print(f"[{r.get('verdict','?').upper()}] {r['title']} -> {r.get('reasoning','')}")
        time.sleep(poll_seconds)


if __name__ == "__main__":
    run_forever()
