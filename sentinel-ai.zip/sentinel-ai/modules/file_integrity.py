"""
modules/file_integrity.py
Watches a directory for unauthorized changes (new/modified/deleted files)
using SHA-256 hashing. Baseline is stored in the shared database.
"""

import os
import sys
import hashlib
import json
import time
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import get_conn, log_event


def _hash_file(path):
    h = hashlib.sha256()
    try:
        with open(path, "rb") as f:
            for chunk in iter(lambda: f.read(8192), b""):
                h.update(chunk)
        return h.hexdigest()
    except (IOError, OSError):
        return None


def build_baseline(watch_dir):
    """Hash every file in watch_dir and store as the baseline."""
    conn = get_conn()
    conn.execute("DELETE FROM file_hashes WHERE path LIKE ?", (f"{watch_dir}%",))
    count = 0
    for root, _, files in os.walk(watch_dir):
        for fname in files:
            path = os.path.join(root, fname)
            digest = _hash_file(path)
            if digest:
                conn.execute(
                    "INSERT OR REPLACE INTO file_hashes (path, hash, last_checked) VALUES (?,?,?)",
                    (path, digest, datetime.utcnow().isoformat()),
                )
                count += 1
    conn.commit()
    conn.close()
    log_event("file_integrity", "info", f"Baseline built for {watch_dir}: {count} files hashed")
    return count


def check_once(watch_dir):
    """Compare current state of watch_dir against the stored baseline."""
    conn = get_conn()
    baseline = {row["path"]: row["hash"] for row in conn.execute(
        "SELECT path, hash FROM file_hashes WHERE path LIKE ?", (f"{watch_dir}%",)
    ).fetchall()}

    current_paths = set()
    changes = []

    for root, _, files in os.walk(watch_dir):
        for fname in files:
            path = os.path.join(root, fname)
            current_paths.add(path)
            digest = _hash_file(path)
            if digest is None:
                continue
            if path not in baseline:
                changes.append({"path": path, "change": "new"})
                conn.execute(
                    "INSERT OR REPLACE INTO file_hashes (path, hash, last_checked) VALUES (?,?,?)",
                    (path, digest, datetime.utcnow().isoformat()),
                )
            elif baseline[path] != digest:
                changes.append({"path": path, "change": "modified"})
                conn.execute(
                    "UPDATE file_hashes SET hash=?, last_checked=? WHERE path=?",
                    (digest, datetime.utcnow().isoformat(), path),
                )

    deleted = set(baseline.keys()) - current_paths
    for path in deleted:
        changes.append({"path": path, "change": "deleted"})
        conn.execute("DELETE FROM file_hashes WHERE path = ?", (path,))

    conn.commit()
    conn.close()

    if changes:
        log_event(
            module="file_integrity",
            severity="critical",
            title=f"{len(changes)} file change(s) detected in {watch_dir}",
            details=json.dumps(changes),
        )
    return changes


def watch_loop(watch_dir, interval_seconds=15):
    """Blocking loop - run in a background thread. Ctrl+C to stop standalone."""
    if not get_conn().execute(
        "SELECT COUNT(*) FROM file_hashes WHERE path LIKE ?", (f"{watch_dir}%",)
    ).fetchone()[0]:
        build_baseline(watch_dir)

    while True:
        check_once(watch_dir)
        time.sleep(interval_seconds)


if __name__ == "__main__":
    directory = sys.argv[1] if len(sys.argv) > 1 else "."
    print(f"Monitoring {directory} every 15s... (Ctrl+C to stop)")
    watch_loop(directory)
