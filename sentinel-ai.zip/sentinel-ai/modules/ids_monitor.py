"""
modules/ids_monitor.py
Combined packet sniffer + lightweight intrusion detection system.

Detects:
  - Port scan patterns (many distinct ports from same source, short window)
  - SYN floods / high packet rate from a single source
  - Basic protocol anomalies

Requires: scapy, and root privileges (run with sudo) to sniff.
Run this ONLY on a network/interface you own or are authorized to monitor.
"""

import sys, os, json, time
from collections import defaultdict, deque
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import log_event

try:
    from scapy.all import sniff, IP, TCP
    SCAPY_AVAILABLE = True
except ImportError:
    SCAPY_AVAILABLE = False

# source_ip -> deque of (timestamp, dest_port)
_recent_connections = defaultdict(lambda: deque(maxlen=200))

PORT_SCAN_THRESHOLD = 15      # distinct ports
PORT_SCAN_WINDOW = 10         # seconds
FLOOD_THRESHOLD = 100         # packets
FLOOD_WINDOW = 5              # seconds


def _check_port_scan(src_ip):
    now = time.time()
    conns = _recent_connections[src_ip]
    recent = [c for c in conns if now - c[0] <= PORT_SCAN_WINDOW]
    distinct_ports = {c[1] for c in recent}
    if len(distinct_ports) >= PORT_SCAN_THRESHOLD:
        log_event(
            module="ids_monitor",
            severity="critical",
            title=f"Possible port scan detected from {src_ip}",
            details=json.dumps({"src_ip": src_ip, "distinct_ports": len(distinct_ports)}),
        )
        return True
    return False


def _check_flood(src_ip):
    now = time.time()
    conns = _recent_connections[src_ip]
    recent = [c for c in conns if now - c[0] <= FLOOD_WINDOW]
    if len(recent) >= FLOOD_THRESHOLD:
        log_event(
            module="ids_monitor",
            severity="critical",
            title=f"Possible SYN flood / high packet rate from {src_ip}",
            details=json.dumps({"src_ip": src_ip, "packet_count": len(recent)}),
        )
        return True
    return False


def _handle_packet(pkt):
    if IP in pkt and TCP in pkt:
        src_ip = pkt[IP].src
        dst_port = pkt[TCP].dport
        _recent_connections[src_ip].append((time.time(), dst_port))
        _check_port_scan(src_ip)
        _check_flood(src_ip)


def start_monitoring(interface=None, packet_count=0):
    """
    Blocking call - sniffs live traffic and feeds the detector.
    packet_count=0 means sniff indefinitely (run this in a background thread).
    """
    if not SCAPY_AVAILABLE:
        log_event(
            module="ids_monitor",
            severity="warning",
            title="Scapy not installed - IDS monitor cannot start",
            details="Run: pip install scapy (and use sudo since raw sockets need root)",
        )
        return

    log_event(
        module="ids_monitor",
        severity="info",
        title=f"IDS monitor started on interface {interface or 'default'}",
    )
    sniff(iface=interface, prn=_handle_packet, store=False, count=packet_count)


if __name__ == "__main__":
    iface = sys.argv[1] if len(sys.argv) > 1 else None
    print("Starting IDS monitor... (Ctrl+C to stop). Needs sudo.")
    start_monitoring(interface=iface)
