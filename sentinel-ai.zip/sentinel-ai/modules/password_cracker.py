"""
modules/password_cracker.py
Educational password strength / cracking demo:
  - Dictionary attack (wordlist)
  - Brute-force attack (character set, up to a max length)
  - Rainbow-table style lookup (precomputed hash -> plaintext dictionary)

Only use this against hashes YOU created for testing/learning, never against
credentials you don't own or have explicit permission to test.
"""

import sys, os, json, hashlib, itertools, time

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import log_event

DEFAULT_WORDLIST = [
    "password", "123456", "qwerty", "letmein", "admin", "welcome",
    "monkey", "dragon", "abc123", "iloveyou", "sunshine", "football",
    "password1", "123456789", "trustno1",
]

CHARSET = "abcdefghijklmnopqrstuvwxyz0123456789"


def hash_password(password, algo="sha256"):
    h = hashlib.new(algo)
    h.update(password.encode())
    return h.hexdigest()


def build_rainbow_table(wordlist=None, algo="sha256"):
    wordlist = wordlist or DEFAULT_WORDLIST
    return {hash_password(w, algo): w for w in wordlist}


def rainbow_lookup(target_hash, algo="sha256", wordlist=None):
    table = build_rainbow_table(wordlist, algo)
    return table.get(target_hash)


def dictionary_attack(target_hash, algo="sha256", wordlist=None):
    wordlist = wordlist or DEFAULT_WORDLIST
    for word in wordlist:
        if hash_password(word, algo) == target_hash:
            return word
    return None


def brute_force_attack(target_hash, algo="sha256", max_length=4, charset=CHARSET):
    """Warning: grows exponentially - keep max_length small for demos (<=5)."""
    for length in range(1, max_length + 1):
        for combo in itertools.product(charset, repeat=length):
            candidate = "".join(combo)
            if hash_password(candidate, algo) == target_hash:
                return candidate
    return None


def crack(target_hash, algo="sha256", wordlist=None, try_brute_force=True, max_brute_length=4):
    """Runs rainbow -> dictionary -> (optional) brute force, in that order (fastest first)."""
    start = time.time()
    methods_tried = []

    result = rainbow_lookup(target_hash, algo, wordlist)
    methods_tried.append("rainbow_table")
    if result is None:
        result = dictionary_attack(target_hash, algo, wordlist)
        methods_tried.append("dictionary")
    if result is None and try_brute_force:
        result = brute_force_attack(target_hash, algo, max_brute_length)
        methods_tried.append("brute_force")

    elapsed = round(time.time() - start, 3)
    severity = "critical" if result else "info"
    log_event(
        module="password_cracker",
        severity=severity,
        title=f"Password crack attempt: {'CRACKED' if result else 'not cracked'} ({elapsed}s)",
        details=json.dumps({
            "hash": target_hash, "algo": algo,
            "methods_tried": methods_tried, "elapsed_seconds": elapsed,
            "result_length": len(result) if result else None,
        }),
    )
    return {"cracked": result is not None, "password": result, "methods_tried": methods_tried, "elapsed_seconds": elapsed}


if __name__ == "__main__":
    # Demo: hash a weak password ourselves, then try to crack it
    demo_password = sys.argv[1] if len(sys.argv) > 1 else "password1"
    target_hash = hash_password(demo_password)
    print(f"Target hash (sha256 of '{demo_password}'): {target_hash}")
    result = crack(target_hash, max_brute_length=4)
    print(json.dumps(result, indent=2))
