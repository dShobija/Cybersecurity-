"""
modules/phishing_detector.py
Analyzes a URL for common phishing signals:
  - Domain age (via WHOIS) - very new domains are higher risk
  - SSL certificate presence/validity
  - Suspicious URL structure (IP-based host, excessive subdomains, lookalike chars)
  - Page content signals (login form present, brand-name mentions vs actual domain)

Produces a simple risk score - not a definitive verdict. Always verify manually.
"""

import sys, os, json, re, ssl, socket
from datetime import datetime, timezone
from urllib.parse import urlparse

import requests

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import log_event

try:
    import whois
    WHOIS_AVAILABLE = True
except ImportError:
    WHOIS_AVAILABLE = False

BRAND_KEYWORDS = ["paypal", "google", "microsoft", "apple", "amazon", "netflix", "bank", "facebook", "instagram"]
SUSPICIOUS_TLDS = [".zip", ".mov", ".xyz", ".top", ".click", ".gq", ".tk"]


def _is_ip_host(host):
    return bool(re.match(r"^\d{1,3}(\.\d{1,3}){3}$", host))


def _check_ssl(host, port=443, timeout=5):
    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((host, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=host) as ssock:
                cert = ssock.getpeercert()
                return True, cert
    except Exception:
        return False, None


def _check_domain_age(host):
    if not WHOIS_AVAILABLE:
        return None
    try:
        w = whois.whois(host)
        created = w.creation_date
        if isinstance(created, list):
            created = created[0]
        if created:
            if created.tzinfo is None:
                created = created.replace(tzinfo=timezone.utc)
            age_days = (datetime.now(timezone.utc) - created).days
            return age_days
    except Exception:
        return None
    return None


def _check_url_structure(url, host):
    signals = []
    if _is_ip_host(host):
        signals.append("URL uses a raw IP address instead of a domain name")
    if host.count(".") >= 4:
        signals.append("Unusually deep subdomain structure")
    if any(host.endswith(tld) for tld in SUSPICIOUS_TLDS):
        signals.append(f"Uses a TLD commonly abused in phishing ({host.split('.')[-1]})")
    for brand in BRAND_KEYWORDS:
        if brand in host and not host.endswith(f"{brand}.com"):
            signals.append(f"Mentions brand '{brand}' but domain isn't the official one")
    return signals


def _check_page_content(url, host, timeout=6):
    signals = []
    try:
        resp = requests.get(url, timeout=timeout)
        body = resp.text.lower()
        has_login_form = "<form" in body and ("password" in body or "type=\"password\"" in body)
        if has_login_form:
            signals.append("Page contains a login/password form")
        for brand in BRAND_KEYWORDS:
            if brand in body and brand not in host:
                signals.append(f"Page content mentions '{brand}' but domain does not match")
                break
    except requests.RequestException:
        signals.append("Could not fetch page content (may be down or blocking bots)")
    return signals


def analyze_url(url):
    parsed = urlparse(url if "://" in url else f"http://{url}")
    host = parsed.netloc or parsed.path

    risk_signals = []
    risk_signals += _check_url_structure(url, host)

    ssl_ok, _ = _check_ssl(host)
    if not ssl_ok:
        risk_signals.append("No valid SSL certificate found on port 443")

    age_days = _check_domain_age(host)
    if age_days is not None and age_days < 30:
        risk_signals.append(f"Domain registered very recently ({age_days} days ago)")

    risk_signals += _check_page_content(url, host)

    score = min(len(risk_signals) * 20, 100)
    risk_level = "critical" if score >= 60 else ("warning" if score >= 20 else "info")

    log_event(
        module="phishing_detector",
        severity=risk_level,
        title=f"Phishing analysis for {host}: risk score {score}/100",
        details=json.dumps({"url": url, "host": host, "signals": risk_signals, "score": score}),
    )
    return {"url": url, "host": host, "risk_score": score, "signals": risk_signals}


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "http://example.com"
    print(f"Analyzing {target} ...")
    result = analyze_url(target)
    print(json.dumps(result, indent=2))
