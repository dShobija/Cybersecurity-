"""
modules/encrypted_chat.py
A minimal end-to-end encrypted chat between two users over plain TCP sockets.
  - RSA (2048-bit) key exchange: each side generates a keypair, exchanges
    public keys, then encrypts a random AES session key with the peer's
    RSA public key.
  - AES-256 (EAX mode) is then used to encrypt/decrypt the actual messages.
No server in the middle can read the messages - only the two endpoints hold
the private keys needed to unwrap the AES session key.

Usage (run in two separate terminals, on the same machine or LAN):
    python3 encrypted_chat.py listen 5001
    python3 encrypted_chat.py connect <host> 5001

Requires: pip install pycryptodome
"""

import sys, os, socket, threading, json, base64

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import log_event

from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP, AES
from Crypto.Random import get_random_bytes


def _send_json(sock, obj):
    data = json.dumps(obj).encode()
    sock.sendall(len(data).to_bytes(4, "big") + data)


def _recv_json(sock):
    length_bytes = sock.recv(4)
    if not length_bytes:
        return None
    length = int.from_bytes(length_bytes, "big")
    data = b""
    while len(data) < length:
        chunk = sock.recv(length - len(data))
        if not chunk:
            break
        data += chunk
    return json.loads(data.decode())


def _b64(b):
    return base64.b64encode(b).decode()


def _unb64(s):
    return base64.b64decode(s.encode())


def _encrypt_message(aes_key, plaintext):
    cipher = AES.new(aes_key, AES.MODE_EAX)
    ciphertext, tag = cipher.encrypt_and_digest(plaintext.encode())
    return {"nonce": _b64(cipher.nonce), "tag": _b64(tag), "ciphertext": _b64(ciphertext)}


def _decrypt_message(aes_key, payload):
    cipher = AES.new(aes_key, AES.MODE_EAX, nonce=_unb64(payload["nonce"]))
    plaintext = cipher.decrypt_and_verify(_unb64(payload["ciphertext"]), _unb64(payload["tag"]))
    return plaintext.decode()


def _key_exchange_as_listener(conn):
    my_key = RSA.generate(2048)
    conn.sendall(my_key.publickey().export_key())
    peer_pub_bytes = conn.recv(4096)
    peer_pub = RSA.import_key(peer_pub_bytes)

    aes_key = get_random_bytes(32)
    enc_aes_key = PKCS1_OAEP.new(peer_pub).encrypt(aes_key)
    conn.sendall(len(enc_aes_key).to_bytes(4, "big") + enc_aes_key)
    return aes_key


def _key_exchange_as_client(conn):
    my_key = RSA.generate(2048)
    peer_pub_bytes = conn.recv(4096)
    peer_pub = RSA.import_key(peer_pub_bytes)
    conn.sendall(my_key.publickey().export_key())

    length = int.from_bytes(conn.recv(4), "big")
    enc_aes_key = b""
    while len(enc_aes_key) < length:
        enc_aes_key += conn.recv(length - len(enc_aes_key))
    aes_key = PKCS1_OAEP.new(my_key).decrypt(enc_aes_key)
    return aes_key


def _receive_loop(conn, aes_key):
    while True:
        payload = _recv_json(conn)
        if payload is None:
            print("\n[connection closed by peer]")
            os._exit(0)
        try:
            message = _decrypt_message(aes_key, payload)
            print(f"\nPeer: {message}\nYou: ", end="", flush=True)
        except Exception:
            print("\n[failed to decrypt an incoming message - possible tampering]")


def _chat_loop(conn, aes_key):
    threading.Thread(target=_receive_loop, args=(conn, aes_key), daemon=True).start()
    while True:
        msg = input("You: ")
        if msg.strip().lower() in ("/quit", "/exit"):
            conn.close()
            break
        payload = _encrypt_message(aes_key, msg)
        _send_json(conn, payload)


def listen(port):
    server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    server.bind(("0.0.0.0", port))
    server.listen(1)
    print(f"Listening on port {port} ... waiting for peer to connect")
    conn, addr = server.accept()
    print(f"Peer connected from {addr}")
    aes_key = _key_exchange_as_listener(conn)
    log_event("encrypted_chat", "info", f"Encrypted chat session established with {addr[0]}")
    print("Secure channel established (RSA-2048 + AES-256-EAX). Type /quit to exit.")
    _chat_loop(conn, aes_key)


def connect(host, port):
    conn = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    conn.connect((host, port))
    aes_key = _key_exchange_as_client(conn)
    log_event("encrypted_chat", "info", f"Encrypted chat session established with {host}")
    print("Secure channel established (RSA-2048 + AES-256-EAX). Type /quit to exit.")
    _chat_loop(conn, aes_key)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        print("Usage:\n  python3 encrypted_chat.py listen <port>\n  python3 encrypted_chat.py connect <host> <port>")
        sys.exit(1)

    mode = sys.argv[1]
    if mode == "listen":
        listen(int(sys.argv[2]))
    elif mode == "connect":
        connect(sys.argv[2], int(sys.argv[3]))
    else:
        print("Unknown mode. Use 'listen' or 'connect'.")
