"""
modules/keylogger_detector.py
Scans running processes for signals commonly associated with keyloggers:
  - Known keylogger process name patterns
  - Processes with suspiciously high I/O to hidden/log-like files
  - Processes without a visible window that access input devices (Linux: /dev/input)

This is a heuristic scanner, not a guarantee - always confirm findings manually
before taking action, since legitimate software can occasionally look similar.
"""

import sys, os, json, re

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import log_event

try:
    import psutil
    PSUTIL_AVAILABLE = True
except ImportError:
    PSUTIL_AVAILABLE = False

SUSPICIOUS_NAME_PATTERNS = [
    r"key\s*log", r"keylog", r"klog", r"kspy", r"logkeys",
    r"xkey", r"input.?spy", r"keycapture",
]

SUSPICIOUS_FILE_PATTERNS = [
    r"\.log$", r"keystrokes", r"keys\.txt", r"\.klg$",
]


def _name_looks_suspicious(name):
    name = (name or "").lower()
    return any(re.search(p, name) for p in SUSPICIOUS_NAME_PATTERNS)


def _open_files_look_suspicious(proc):
    try:
        for f in proc.open_files():
            path = f.path.lower()
            if any(re.search(p, path) for p in SUSPICIOUS_FILE_PATTERNS):
                return True, f.path
    except (psutil.AccessDenied, psutil.NoSuchProcess, Exception):
        pass
    return False, None


def _accesses_input_devices(proc):
    """On Linux, keyloggers often read directly from /dev/input/*"""
    try:
        for f in proc.open_files():
            if "/dev/input" in f.path:
                return True, f.path
    except (psutil.AccessDenied, psutil.NoSuchProcess, Exception):
        pass
    return False, None


def scan_processes():
    if not PSUTIL_AVAILABLE:
        log_event("keylogger_detector", "warning", "psutil not installed - cannot scan processes",
                   details="Run: pip install psutil")
        return []

    findings = []
    for proc in psutil.process_iter(["pid", "name", "exe", "username"]):
        info = proc.info
        reasons = []

        if _name_looks_suspicious(info.get("name")):
            reasons.append(f"Process name matches keylogger-like pattern: {info.get('name')}")

        file_flag, file_path = _open_files_look_suspicious(proc)
        if file_flag:
            reasons.append(f"Writing to suspicious log-like file: {file_path}")

        input_flag, input_path = _accesses_input_devices(proc)
        if input_flag:
            reasons.append(f"Directly reading input device: {input_path}")

        if reasons:
            findings.append({
                "pid": info.get("pid"),
                "name": info.get("name"),
                "user": info.get("username"),
                "reasons": reasons,
            })

    severity = "critical" if findings else "info"
    log_event(
        module="keylogger_detector",
        severity=severity,
        title=f"Process scan: {len(findings)} suspicious process(es) found",
        details=json.dumps(findings),
    )
    return findings


if __name__ == "__main__":
    print("Scanning running processes for keylogger-like behavior...")
    results = scan_processes()
    for r in results:
        print(f"  PID {r['pid']} ({r['name']}): {r['reasons']}")
    if not results:
        print("  No suspicious processes found.")
