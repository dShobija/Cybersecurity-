"""
modules/web_vuln_scanner.py
Crawls a target site and tests for common vulnerabilities:
  - SQL injection (basic error-based detection)
  - Reflected XSS (payload reflection check)
  - Broken authentication signals (login forms over HTTP, missing CSRF token)

Run only against sites you own or have explicit written permission to test.
"""

import sys, os, json
import requests
from urllib.parse import urljoin, urlparse
from bs4 import BeautifulSoup

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import log_event

SQLI_PAYLOADS = ["'", "' OR '1'='1", "1' ORDER BY 1--"]
SQLI_ERROR_SIGNATURES = [
    "sql syntax", "mysql_fetch", "ora-01756", "sqlite3.OperationalError",
    "unclosed quotation mark", "postgresql", "you have an error in your sql",
]
XSS_PAYLOAD = "<script>sentinelAI_xss_test</script>"

MAX_PAGES = 15
TIMEOUT = 6


def _get_forms(html, base_url):
    soup = BeautifulSoup(html, "html.parser")
    forms = []
    for form in soup.find_all("form"):
        action = form.get("action") or base_url
        forms.append({
            "action": urljoin(base_url, action),
            "method": form.get("method", "get").lower(),
            "inputs": [i.get("name") for i in form.find_all("input") if i.get("name")],
        })
    return forms


def _get_links(html, base_url):
    soup = BeautifulSoup(html, "html.parser")
    domain = urlparse(base_url).netloc
    links = set()
    for a in soup.find_all("a", href=True):
        full = urljoin(base_url, a["href"])
        if urlparse(full).netloc == domain:
            links.add(full.split("#")[0])
    return links


def _test_form_sqli(form):
    for payload in SQLI_PAYLOADS:
        data = {name: payload for name in form["inputs"]}
        try:
            if form["method"] == "post":
                resp = requests.post(form["action"], data=data, timeout=TIMEOUT)
            else:
                resp = requests.get(form["action"], params=data, timeout=TIMEOUT)
        except requests.RequestException:
            continue
        body = resp.text.lower()
        if any(sig in body for sig in SQLI_ERROR_SIGNATURES):
            return True, payload
    return False, None


def _test_form_xss(form):
    data = {name: XSS_PAYLOAD for name in form["inputs"]}
    try:
        if form["method"] == "post":
            resp = requests.post(form["action"], data=data, timeout=TIMEOUT)
        else:
            resp = requests.get(form["action"], params=data, timeout=TIMEOUT)
    except requests.RequestException:
        return False
    return XSS_PAYLOAD in resp.text


def _check_auth_hygiene(url, forms):
    findings = []
    if urlparse(url).scheme != "https":
        for form in forms:
            if any("pass" in (i or "").lower() for i in form["inputs"]):
                findings.append("Login/password form served over plain HTTP")
                break
    return findings


def scan_site(start_url, max_pages=MAX_PAGES):
    visited = set()
    to_visit = {start_url}
    findings = []

    while to_visit and len(visited) < max_pages:
        url = to_visit.pop()
        if url in visited:
            continue
        visited.add(url)

        try:
            resp = requests.get(url, timeout=TIMEOUT)
        except requests.RequestException:
            continue

        forms = _get_forms(resp.text, url)
        for form in forms:
            if form["inputs"]:
                is_vuln, payload = _test_form_sqli(form)
                if is_vuln:
                    findings.append({"type": "sqli", "url": form["action"], "payload": payload})
                if _test_form_xss(form):
                    findings.append({"type": "xss", "url": form["action"]})

        for issue in _check_auth_hygiene(url, forms):
            findings.append({"type": "auth_hygiene", "url": url, "detail": issue})

        to_visit |= (_get_links(resp.text, url) - visited)

    severity = "critical" if any(f["type"] in ("sqli", "xss") for f in findings) else (
        "warning" if findings else "info"
    )
    log_event(
        module="web_vuln_scanner",
        severity=severity,
        title=f"Scanned {start_url}: {len(findings)} finding(s) across {len(visited)} page(s)",
        details=json.dumps(findings),
    )
    return findings


if __name__ == "__main__":
    target = sys.argv[1] if len(sys.argv) > 1 else "http://127.0.0.1"
    print(f"Crawling & testing {target} ...")
    results = scan_site(target)
    for f in results:
        print(" -", f)
    if not results:
        print("No issues found (within tested pages/payloads).")
