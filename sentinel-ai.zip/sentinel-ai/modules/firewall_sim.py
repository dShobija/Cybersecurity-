"""
modules/firewall_sim.py
A rule-based firewall SIMULATOR. It does not actually block real traffic on
your network interface - it evaluates simulated or live-observed packets
against a rule set so you can see what WOULD be blocked and why. This is the
safe way to learn firewall logic without touching real iptables rules.

Rules are simple dicts: {action, direction, protocol, src, dst, port}
"action" = "allow" | "block"
"protocol" = "tcp" | "udp" | "any"
"src"/"dst" = IP, CIDR-like prefix, or "any"
"port" = int or "any"
First matching rule wins (like real firewalls); default is "block" if nothing matches.
"""

import sys, os, json
from datetime import datetime

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import log_event, get_conn

DEFAULT_RULES = [
    {"action": "allow", "direction": "in", "protocol": "tcp", "src": "any", "dst": "any", "port": 22},
    {"action": "allow", "direction": "in", "protocol": "tcp", "src": "any", "dst": "any", "port": 443},
    {"action": "allow", "direction": "in", "protocol": "tcp", "src": "any", "dst": "any", "port": 80},
    {"action": "block", "direction": "in", "protocol": "tcp", "src": "any", "dst": "any", "port": 23},   # telnet
    {"action": "block", "direction": "in", "protocol": "any", "src": "any", "dst": "any", "port": "any"},  # default deny
]


def _matches(rule, packet):
    if rule["direction"] != packet["direction"]:
        return False
    if rule["protocol"] != "any" and rule["protocol"] != packet["protocol"]:
        return False
    if rule["src"] != "any" and rule["src"] != packet["src"]:
        return False
    if rule["dst"] != "any" and rule["dst"] != packet["dst"]:
        return False
    if rule["port"] != "any" and rule["port"] != packet["port"]:
        return False
    return True


def evaluate_packet(packet, rules=None):
    rules = rules or DEFAULT_RULES
    for rule in rules:
        if _matches(rule, packet):
            return rule["action"], rule
    return "block", None  # implicit default deny


def evaluate_batch(packets, rules=None, log_results=True):
    results = []
    for pkt in packets:
        action, rule = evaluate_packet(pkt, rules)
        results.append({"packet": pkt, "action": action, "matched_rule": rule})

    if log_results:
        blocked = [r for r in results if r["action"] == "block"]
        severity = "warning" if blocked else "info"
        log_event(
            module="firewall_sim",
            severity=severity,
            title=f"Evaluated {len(packets)} packet(s): {len(blocked)} blocked",
            details=json.dumps(results),
        )
    return results


def sample_traffic():
    """A small demo batch of simulated packets, useful for testing the dashboard button."""
    return [
        {"direction": "in", "protocol": "tcp", "src": "203.0.113.5", "dst": "10.0.0.5", "port": 22},
        {"direction": "in", "protocol": "tcp", "src": "203.0.113.9", "dst": "10.0.0.5", "port": 23},
        {"direction": "in", "protocol": "tcp", "src": "198.51.100.2", "dst": "10.0.0.5", "port": 4444},
        {"direction": "in", "protocol": "tcp", "src": "198.51.100.7", "dst": "10.0.0.5", "port": 443},
    ]


if __name__ == "__main__":
    print("Running firewall simulator on sample traffic...")
    results = evaluate_batch(sample_traffic())
    for r in results:
        p = r["packet"]
        print(f"  {p['src']}:{p['port']} -> {p['dst']}  [{r['action'].upper()}]")
