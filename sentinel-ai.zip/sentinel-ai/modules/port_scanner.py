"""
modules/port_scanner.py
Scans a target IP for open ports and guesses the running service.
Run only against systems you own or have explicit permission to test.
"""

import socket
import json
from datetime import datetime
from concurrent.futures import ThreadPoolExecutor

import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from database import get_conn, log_event

COMMON_PORTS = {
    21: "FTP", 22: "SSH", 23: "Telnet", 25: "SMTP", 53: "DNS",
    80: "HTTP", 110: "POP3", 139: "NetBIOS", 143: "IMAP",
    443: "HTTPS", 445: "SMB", 3306: "MySQL", 3389: "RDP",
    5432: "PostgreSQL", 8080: "HTTP-Alt", 8443: "HTTPS-Alt",
}


def scan_port(target, port, timeout=0.6):
    sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    sock.settimeout(timeout)
    try:
        result = sock.connect_ex((target, port))
        if result == 0:
            service = COMMON_PORTS.get(port, "unknown")
            return (port, "open", service)
        return (port, "closed", None)
    except socket.error:
        return (port, "error", None)
    finally:
        sock.close()


def scan_target(target, ports=None, max_workers=100):
    """Scan a target and store + log results. Returns list of open ports."""
    if ports is None:
        ports = list(COMMON_PORTS.keys())

    open_ports = []
    conn = get_conn()
    timestamp = datetime.utcnow().isoformat()

    with ThreadPoolExecutor(max_workers=max_workers) as executor:
        results = executor.map(lambda p: scan_port(target, p), ports)

    for port, state, service in results:
        if state == "open":
            open_ports.append({"port": port, "service": service})
            conn.execute(
                "INSERT INTO port_scans (timestamp, target, port, state, service) VALUES (?,?,?,?,?)",
                (timestamp, target, port, state, service),
            )

    conn.commit()
    conn.close()

    severity = "warning" if open_ports else "info"
    log_event(
        module="port_scanner",
        severity=severity,
        title=f"Scanned {target}: {len(open_ports)} open port(s)",
        details=json.dumps({"target": target, "open_ports": open_ports}),
    )
    return open_ports


if __name__ == "__main__":
    import sys
    target = sys.argv[1] if len(sys.argv) > 1 else "127.0.0.1"
    print(f"Scanning {target} ...")
    found = scan_target(target)
    for p in found:
        print(f"  Port {p['port']} OPEN ({p['service']})")
    if not found:
        print("  No open ports found in common port list.")
